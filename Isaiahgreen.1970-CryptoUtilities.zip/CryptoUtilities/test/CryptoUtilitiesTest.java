import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * @author Isaiah Green
 *
 */
public class CryptoUtilitiesTest {

    /*
     * Tests of reduceToGCD
     */

    @Test
    public void testReduceToGCD_0_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("0", n.toString());
        assertEquals("0", m.toString());
    }
    /*
     * The test is a boundary
     */

    @Test
    public void testReduceToGCD_30_21() {
        NaturalNumber n = new NaturalNumber2(30);
        NaturalNumber m = new NaturalNumber2(21);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("3", n.toString());
        assertEquals("0", m.toString());
    }

    /*
     * The test is a routine
     */
    @Test
    public void testReduceToGCD_9001_9000() {
        NaturalNumber n = new NaturalNumber2(9001);
        NaturalNumber m = new NaturalNumber2(9000);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("1", n.toString());
        assertEquals("0", m.toString());
    }
    /*
     * The test is a challenging
     */

    /*
     * Tests of isEven
     */

    @Test
    public void testIsEven_0() {
        NaturalNumber n = new NaturalNumber2(0);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("0", n.toString());
        assertTrue(result);
    }

    /*
     * The test is a boundary
     */

    @Test
    public void testIsEven_1() {
        NaturalNumber n = new NaturalNumber2(1);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("1", n.toString());
        assertTrue(!result);
    }

    /*
     * The test is a routine
     */
    @Test
    public void testIsEven_6917() {
        NaturalNumber n = new NaturalNumber2(6917);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("6917", n.toString());
        assertTrue(!result);
    }

    /*
     * The test is a challenging
     */
    @Test
    public void testIsEven_34588973() {
        NaturalNumber n = new NaturalNumber2(34588973);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("34588973", n.toString());
        assertTrue(!result);
    }
    /*
     * The test is a challenging
     */

    /*
     * Tests of powerMod
     */

    @Test
    public void testPowerMod_0_0_2() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber p = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(2);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("0", p.toString());
        assertEquals("2", m.toString());
    }

    /*
     * The test is a boundary
     */

    @Test
    public void testPowerMod_17_18_19() {
        NaturalNumber n = new NaturalNumber2(17);
        NaturalNumber p = new NaturalNumber2(18);
        NaturalNumber m = new NaturalNumber2(19);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("18", p.toString());
        assertEquals("19", m.toString());
    }
    /*
     * The test is a routine
     */

    @Test
    public void testPowerMod_754_15_09() {
        NaturalNumber n = new NaturalNumber2(754);
        NaturalNumber p = new NaturalNumber2(15);
        NaturalNumber m = new NaturalNumber2(9);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("15", p.toString());
        assertEquals("9", m.toString());
    }

    /*
     * The test is a challenging
     */

    /*
     * Tests of isPrime2
     */

    @Test
    public void testisPrime2_71() {
        NaturalNumber n = new NaturalNumber2(71);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);
    }
    /*
     * The test is a boundary
     */

    @Test
    public void testisPrime2_257() {
        NaturalNumber n = new NaturalNumber2(257);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);
    }
    /*
     * The test is a routine
     */

    @Test
    public void testisPrime2_5069() {

        NaturalNumber n = new NaturalNumber2(5069);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(!result);

    }

    @Test
    public void testisPrime2_9967() {
        NaturalNumber n = new NaturalNumber2(9967);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);

    }

    /*
     * The test is a challenging
     */

    /*
     * Tests of isWitnessToCompositeness
     */

    @Test
    public void testisWitnessToCompositeness_4_7() {
        NaturalNumber w = new NaturalNumber2(4);
        NaturalNumber n = new NaturalNumber2(7);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(!result);
    }

    /*
     * The test is a boundary
     */
    @Test
    public void testisWitnessToCompositeness_304_307() {
        NaturalNumber w = new NaturalNumber2(304);
        NaturalNumber n = new NaturalNumber2(307);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(!result);
    }
    /*
     * The test is a routine
     */

    @Test
    public void testisWitnessToCompositeness_1003_1007() {

        NaturalNumber x = new NaturalNumber2(1003);
        NaturalNumber n = new NaturalNumber2(1007);
        boolean result = CryptoUtilities.isWitnessToCompositeness(x, n);
        assertTrue(result);
    }

    @Test
    public void testisWitnessToCompositeness_4721_6121() {
        NaturalNumber w = new NaturalNumber2(4721);
        NaturalNumber n = new NaturalNumber2(6121);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(!result);
    }

    /*
     * The test is a challenging
     */

    /*
     * Tests of generateNextLikelyPrime
     */

    @Test
    public void testgenerateNextLikelyPrime_3478() {

        NaturalNumber n = new NaturalNumber2(3478);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("3491", n.toString());
    }
    /*
     * The test is a boundary
     */

    @Test
    public void testgenerateNextLikelyPrime_14() {
        NaturalNumber n = new NaturalNumber2(14);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("17", n.toString());
    }

    /*
     * The test is a routine
     */
    @Test
    public void testgenerateNextLikelyPrime_17388() {

        NaturalNumber n = new NaturalNumber2(17388);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("17389", n.toString());
    }

    @Test
    public void testgenerateNextLikelyPrime_5() {
        NaturalNumber n = new NaturalNumber2(5);
        assertEquals("5", n.toString());

    }

    /*
     * The test is a challenging
     */
}
