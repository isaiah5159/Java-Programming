import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class GlossaryTest {

    @Test
    public void listInOrder() {

        Map<String, String> x = new Map1L<>();
        String m = "thought of apart from concrete realities";
        String k = "abstract";
        x.add(k, m);
        Queue<String> termsSort = new Queue1L<>();
        Glossary.listInOrder(x, termsSort);
        Queue<String> expected = new Queue1L<>();
        expected.enqueue(k);
        assertEquals(termsSort, expected);
    }
    /*
     * The test is a boundary
     */

    @Test
    public void listInOrder1() {

        Map<String, String> x = new Map1L<>();
        String m = "spending much more than is necessary or wise";
        String k = "extravagant";
        x.add(k, m);
        Queue<String> termsSort = new Queue1L<>();
        Glossary.listInOrder(x, termsSort);
        Queue<String> expected = new Queue1L<>();
        expected.enqueue(k);
        assertEquals(termsSort, expected);
    }

    /*
     * The test is a routine
     */

    @Test
    public void listInOrder2() {

        Map<String, String> x = new Map1L<>();
        String m = "used as a nonsense word by children to express approval or to represent the longest word in English";
        String k = "supercalifragilisticexpialidocious";
        x.add(k, m);
        Queue<String> termsSort = new Queue1L<>();
        Glossary.listInOrder(x, termsSort);
        Queue<String> expected = new Queue1L<>();
        expected.enqueue(k);
        assertEquals(termsSort, expected);
    }

    /*
     * The test is a challenging
     */

    @Test
    public void indexList() {

        SimpleWriter x = new SimpleWriter1L("A.txt");
        Queue<String> actual = new Queue1L<>();
        Queue<String> termsSort = new Queue1L<>();
        String t1 = "book";
        String t2 = "abstract";
        Queue<String> termsSortC = new Queue1L<>();
        termsSort.enqueue(t1);
        termsSort.enqueue(t2);
        termsSortC.enqueue(t1);
        termsSortC.enqueue(t2);
        Glossary.indexList(x, termsSort);
        SimpleReader testing = new SimpleReader1L("A.txt");
        while (!testing.atEOS()) {
            actual.enqueue(testing.nextLine());
        }
        String t3 = "<ul><li> <a href = book.html>book</a></li><li> <a href = abstract.html>abstract</a></li></ul></body></html>";
        Queue<String> act = new Queue1L<>();
        act.enqueue(t3);
        assertEquals(act, actual);
        assertEquals(termsSortC, termsSort);
        testing.close();
    }
    /*
     * The test is a boundary
     */

    @Test
    public void indexList1() {

        SimpleWriter x = new SimpleWriter1L("B.txt");
        Queue<String> actual = new Queue1L<>();
        Queue<String> termsSort = new Queue1L<>();
        String t1 = "book";
        String t2 = "abstract";
        String t4 = "69";
        String t5 = "yeehaw";
        Queue<String> termsSortC = new Queue1L<>();
        termsSort.enqueue(t1);
        termsSort.enqueue(t2);
        termsSort.enqueue(t4);
        termsSort.enqueue(t5);
        termsSortC.enqueue(t1);
        termsSortC.enqueue(t2);
        termsSortC.enqueue(t4);
        termsSortC.enqueue(t5);
        Glossary.indexList(x, termsSort);
        SimpleReader testing = new SimpleReader1L("B.txt");
        while (!testing.atEOS()) {
            actual.enqueue(testing.nextLine());
        }
        String t3 = "<ul><li> <a href = book.html>book</a></li><li> <a href = abstract.html>abstract</a></li><li> <a href = 69.html>69</a></li><li> <a href = yeehaw.html>yeehaw</a></li></ul></body></html>";
        Queue<String> act = new Queue1L<>();
        act.enqueue(t3);
        assertEquals(act, actual);
        assertEquals(termsSortC, termsSort);
        testing.close();
    }

    /*
     * The test is a routine
     */

    @Test
    public void indexList2() {

        SimpleWriter x = new SimpleWriter1L("C.txt");
        Queue<String> actual = new Queue1L<>();
        Queue<String> termsSort = new Queue1L<>();
        String t1 = "and";
        String t2 = "his";
        String t4 = "name";
        String t5 = "name";
        String t6 = "was";
        String t7 = "john";
        String t8 = "cena";
        String t9 = "69";
        Queue<String> termsSortC = new Queue1L<>();
        termsSort.enqueue(t1);
        termsSort.enqueue(t2);
        termsSort.enqueue(t4);
        termsSort.enqueue(t5);
        termsSort.enqueue(t6);
        termsSort.enqueue(t7);
        termsSort.enqueue(t8);
        termsSort.enqueue(t9);
        termsSortC.enqueue(t1);
        termsSortC.enqueue(t2);
        termsSortC.enqueue(t4);
        termsSortC.enqueue(t5);
        termsSortC.enqueue(t6);
        termsSortC.enqueue(t7);
        termsSortC.enqueue(t8);
        termsSortC.enqueue(t9);
        Glossary.indexList(x, termsSort);
        SimpleReader testing = new SimpleReader1L("C.txt");
        while (!testing.atEOS()) {
            actual.enqueue(testing.nextLine());
        }
        String t3 = "<ul><li> <a href = and.html>and</a></li><li> <a href = his.html>his</a></li><li> <a href = name.html>name</a></li><li> <a href = name.html>name</a></li><li> <a href = was.html>was</a></li><li> <a href = john.html>john</a></li><li> <a href = cena.html>cena</a></li><li> <a href = 69.html>69</a></li></ul></body></html>";
        Queue<String> act = new Queue1L<>();
        act.enqueue(t3);
        assertEquals(act, actual);
        assertEquals(termsSortC, termsSort);
        testing.close();
    }

    /*
     * The test is a challenging
     */

    /*
     * Test Cases for nextWordOrSeparator
     */

    @Test
    public void nextWordOrSeparator() {
        int x = 0;
        String y = "hello";
        String s = "hello     world";
        Set<Character> expected = new Set1L<>();
        expected.add(' ');
        expected.add('\t');
        expected.add(',');
        String k = Glossary.nextWordOrSeparator(s, x, expected);
        assertEquals(k, y);
    }
    /*
     * The test is a boundary
     */

    @Test
    public void nextWordOrSeparator1() {
        int x = 6;
        String y = "    ";
        String s = "hello     world";
        Set<Character> expected = new Set1L<>();
        expected.add(' ');
        expected.add('\t');
        expected.add(',');
        String k = Glossary.nextWordOrSeparator(s, x, expected);
        assertEquals(k, y);
    }
    /*
     * The test is a routine
     */

    @Test
    public void nextWordOrSeparator2() {
        int x = 5;
        String y = "     ";
        String s = "hello     world";
        Set<Character> expected = new Set1L<>();
        expected.add(' ');
        expected.add('\t');
        expected.add(',');
        String k = Glossary.nextWordOrSeparator(s, x, expected);
        assertEquals(k, y);
    }

    /*
     * The test is a challenging
     */

    /*
     * Test Cases for comparator
     */

    @Test
    public void comparatorTest_1() {
        String value1 = "bunny";
        String value2 = "dog";

        Queue<String> incorrectOrder = new Queue1L<>();
        incorrectOrder.enqueue(value2);
        incorrectOrder.enqueue(value1);
        Comparator<String> order = new Glossary.StringLT();
        incorrectOrder.sort(order);

        Queue<String> correctOrder = new Queue1L<>();
        correctOrder.enqueue(value1);
        correctOrder.enqueue(value2);

        assertEquals(correctOrder, incorrectOrder);
    }

    @Test
    public void comparatorTest_() {
        String value1 = "bunny";
        String value2 = "bunny";

        Queue<String> incorrectOrder = new Queue1L<>();
        incorrectOrder.enqueue(value2);
        incorrectOrder.enqueue(value1);
        Comparator<String> order = new Glossary.StringLT();
        incorrectOrder.sort(order);

        Queue<String> correctOrder = new Queue1L<>();
        correctOrder.enqueue(value1);
        correctOrder.enqueue(value2);

        assertEquals(correctOrder, incorrectOrder);
    }

    @Test
    public void comparatorTest_3() {
        String value1 = "bunny";
        String value2 = "Bunny";

        Queue<String> incorrectOrder = new Queue1L<>();
        incorrectOrder.enqueue(value2);
        incorrectOrder.enqueue(value1);
        Comparator<String> order = new Glossary.StringLT();
        incorrectOrder.sort(order);

        Queue<String> correctOrder = new Queue1L<>();
        correctOrder.enqueue(value1);
        correctOrder.enqueue(value2);

        assertEquals(correctOrder, incorrectOrder);
    }

    /*
     * The test is a challenging
     */

    /*
     * Test Cases for mapOfText
     */

    @Test
    public void mapOfTextTextTest_1() {
        SimpleReader inputFile = new SimpleReader1L(
                "data/challengingForMapOfText.txt");
        Map<String, String> actualMap = Glossary.mapOfText(inputFile);

        //Creating what the actual map should look like
        Map<String, String> expectedMap = new Map1L<>();
        expectedMap.add("medicine",
                "the art or science of restoring or preserving health "
                        + "or due physical condition, as by means of drugs,"
                        + " surgical operations or appliances,"
                        + " or manipulations: often divided into medicine proper,"
                        + " surgery, and obstetrics");
        expectedMap.add("take", "to hold, grasp, or grip");
        expectedMap.add("grip", "the power of gripping");

        //Checking to see if the expected and the actual map are the same
        assertEquals(actualMap.size(), 3);
        assertEquals(expectedMap, actualMap);

    }

    /*
     * The test is a challenging
     */

    @Test
    public void mapOfTextTest_2() {
        SimpleReader inputFile = new SimpleReader1L("data/terms.txt");
        Map<String, String> actualMap = Glossary.mapOfText(inputFile);

        Map<String, String> expectedMap = new Map1L<>();
        expectedMap.add("meaning",
                "something that one wishes to convey, especially by language");
        expectedMap.add("term", "a word whose definition is in a glossary");
        expectedMap.add("word",
                "a string of characters in a language, which has at least one character");
        expectedMap.add("definition",
                "a sequence of words that gives meaning to a term");
        expectedMap.add("glossary",
                "a list of difficult or specialized terms, with their definitions, "
                        + "usually near the end of a book");
        expectedMap.add("language",
                "a set of strings of characters, each of which has meaning");
        expectedMap.add("book", "a printed or written literary work");

        assertEquals(expectedMap, actualMap);
        assertEquals(actualMap.size(), 7);
    }

    /*
     * The test is a boundary
     */

    @Test
    public void mapOfTextTest_3() {
        SimpleReader inputFile = new SimpleReader1L(
                "data/boundryForMapOfText.txt");
        Map<String, String> actualMap = Glossary.mapOfText(inputFile);

        Map<String, String> expectedMap = new Map1L<>();
        expectedMap.add("abstract", "difficult to understand");

        assertEquals(expectedMap, actualMap);
        assertEquals(actualMap.size(), 1);
    }
    /*
     * The test is a routine
     */

}
