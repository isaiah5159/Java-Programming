import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Obtains words and how many times it occurs within a text file and outputs
 * that information in a table
 *
 * @author Isaiah Green
 *
 */
public final class Wordcounter {

    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareToIgnoreCase(o2);
        }
    }

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Wordcounter() {
    }

    /**
     * Outputs starting tags for html file.
     *
     * Tags: <html> <head> <title> <body>
     * <h2>
     *
     * @param out
     *            the output stream
     * @param input
     *            the input file name
     * @updates out.content
     * @requires out.is_open
     * @ensures out.content = #out.content * [the starting tags]
     */
    public static void header(SimpleWriter out, String input) {
        assert out != null : "Violation of: out is not null";
        assert out.isOpen() : "Violation of: out.is_open";

        //outputs opening tags
        out.print("<html> <head> <title> Word Counter </title> </head>");
        out.print("<body> <h2>" + "Words Counted in " + input + "</h2> <hr/>");
    }

    /**
     * Outputs closing tags for the html file
     *
     * Tags:
     * </table>
     * </body> </html>
     *
     * @param out
     *            the output stream
     * @updates out.contents
     * @requires out.is_open
     * @ensures out.content = #out.content * [the HTML "closing" tags]
     */
    private static void footer(SimpleWriter out) {
        assert out != null : "Violation of: out is not null";
        assert out.isOpen() : "Violation of: out.is_open";

        //outputs closing tags
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Counts how many times each word occurs in the text
     *
     * @param pairings
     *            Map that pairs the word with its amount of occurrence
     * @param word
     *            A word in the text
     * @ensures correct occurrences for each word in Pairings
     */
    public static void countWords(Map<String, Integer> pairings, String word) {

        // checks to see if word has appeared before or not and if it has
        //appeared before, then its occurrence is incremented by 1, else its
        //added to the map for the first time
        if ((!pairings.hasKey(word))) {
            pairings.add(word, 1);
        } else {
            pairings.replaceValue(word, pairings.value(word) + 1);
        }
    }

    /**
     * Creates ordered list
     *
     * @param pairings
     *            A map that pairs a word with its corresponding occurrence
     * @param wordsToSort
     *            Queue which will have the words
     *
     * @updates out.content
     * @updates wordsToSort
     *
     * @requires<pre> out.is_open, pairings and wordsToSort
     * are not empty </pre>
     *
     * @ensures wordsToSort = pairings.key()
     */
    public static void listInOrder(Map<String, Integer> pairings,
            Queue<String> wordsToSort) {

        // holds all terms
        Map<String, Integer> temp = new Map1L<>();

        temp.transferFrom(pairings);

        while (temp.size() > 0) {
            Map.Pair<String, Integer> x = temp.removeAny();

            //Stores words in wordsToSort
            wordsToSort.enqueue(x.key());
            pairings.add(x.key(), x.value());

        }
        // sort terms in alphabetical order
        Comparator<String> cs = new StringLT();
        wordsToSort.sort(cs);
    }

    /**
     * Method for displaying the table.
     *
     * @param out
     *            output stream
     * @param pairings
     *            Map with all the words paired with their number of occurrences
     * @param wordsToSort
     *            Queue with sorted words
     * @requires <pre> out.is_open, allWords and wordsToSort aren't empty</pre>
     */
    public static void outputTable(SimpleWriter out,
            Map<String, Integer> pairings, Queue<String> wordsToSort) {

        out.println("<table border = 1>");
        //Printing out ordered list in table format
        while (wordsToSort.length() > 0) {
            String word = wordsToSort.dequeue();
            out.print("<tr> <td>" + word + "</td><td>" + pairings.value(word)
                    + "</td></tr>");
        }
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    public static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";

        char piece = ' ';
        strSet.clear();

        // adds char into set
        for (int i = 0; i < str.length(); i++) {
            if (!strSet.contains(str.charAt(i))) {
                piece = str.charAt(i);
                strSet.add(piece);
            }
        }

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String result = "";
        int k = position;

        // For word with no separators
        if (!separators.contains(text.charAt(position))) {

            // get values that aren't separators
            while (k < text.length() && !separators.contains(text.charAt(k))) {
                k++;
            }

            // gets substring of word
            result = text.substring(position, k);
        }

        // characters that are separators
        else {

            while (k < text.length() && separators.contains(text.charAt(k))) {
                k++;
            }

            // returns separator substring
            result = text.substring(position, k);
        }
        return result;
    }

    /**
     * Method to create a table from a map and ordered queue without including
     * separators
     *
     * @param outputFile
     *            file that table will be output to
     * @param inputFile
     *            text file
     * @param pairings
     *            Map with words paired with how many times it occurs
     * @param wordsToSort
     *            Queue for ordered words
     *
     * @requires <pre> outputFile.is_open, words isn't empty</pre>
     *
     * @ensures wordsToSort will be ordered without separators and a table of
     *          the words will be output.
     */
    public static void createFinalTableWithoutSeparators(
            SimpleWriter outputFile, SimpleReader inputFile,
            Map<String, Integer> pairings, Queue<String> wordsToSort) {

        //create set for separators
        Set<Character> seperators = new Set1L<>();
        // separator string
        final String separatorStr = "\t,.!-?; ";

        generateElements(separatorStr, seperators);

        String str = "";

        // run while stream hasn't reached end
        while (!inputFile.atEOS()) {
            str = inputFile.nextLine();
            int pos = 0;
            while (pos < str.length()) {

                String x = nextWordOrSeparator(str, pos, seperators);
                // if not a separator, count as a word and increment its occurrence
                if (!seperators.contains(x.charAt(0))) {
                    countWords(pairings, x);
                }
                pos += x.length();
            }
        }

        // queue for sorted words
        Queue<String> wordsSort = new Queue1L<>();

        // for listing the words in order
        listInOrder(pairings, wordsSort);

        // print ordered queue as a table
        outputTable(outputFile, pairings, wordsSort);

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // get input file name
        out.print("Enter the name of the input file: ");
        String inputName = in.nextLine();
        SimpleReader inputFile = new SimpleReader1L(inputName);

        //get output file name
        out.print("Enter the name of the output file: ");
        String outputName = in.nextLine();
        SimpleWriter outputFile = new SimpleWriter1L(outputName);

        // output header
        header(outputFile, outputName);

        // declaring map with words
        Map<String, Integer> pairings = new Map1L<>();

        // declaring queue for sorted words
        Queue<String> wordsSort = new Queue1L<>();

        // calling this method to create ordered set of words excluding
        // separators and printing out final table
        createFinalTableWithoutSeparators(outputFile, inputFile, pairings,
                wordsSort);

        // call footer
        footer(outputFile);

        // close input and output streams
        in.close();
        out.close();
        inputFile.close();
        outputFile.close();
    }

}
