import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Damon Steinhauser and Isaiah Green
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /**
     * Sample test cases.
     */
    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }

    /**
     * test add when empty. Boundary test.
     */
    @Test
    public final void testAddEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "green");
        s.add("green");
        assertEquals(sExpected, s);
    }

    /**
     * test add when not empty. Routine test.
     */
    @Test
    public final void testAddNotEmpty() {

        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "red");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "red", "purple");
        s.add("purple");
        assertEquals(sExpected, s);
    }

    /**
     * test add with multiple elements. Challenging test.
     */
    @Test
    public final void testAddMultple() {

        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "red",
                "grey", "silver", "blue");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "red", "grey", "silver", "blue", "purple");
        s.add("purple");
        assertEquals(sExpected, s);
    }

    /**
     * test changeToExtractionMode with multiple elements.
     */
    @Test
    public final void testchangeToExtractionModeMultiple() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "red",
                "blue");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false,
                "red", "blue");
        s.changeToExtractionMode();
        assertEquals(sExpected, s);
    }

    /**
     * test changeToExtractionMode when empty..
     */
    @Test
    public final void testchangeToExtractionModeEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false);
        s.changeToExtractionMode();
        assertEquals(sExpected, s);
    }

    /**
     * test removeFirstEmpty to make empty. Routine test.
     */
    @Test
    public final void testremoveFirstEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "red");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false);
        s.changeToExtractionMode();
        String hold = s.removeFirst();
        assertEquals(sExpected, s);
        assertEquals("red", hold);
    }

    /**
     * test removeFirstEmpty when multiple elements. Routine test.
     */
    @Test
    public final void testremoveFirstFewElements() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "red",
                "blue", "yellow");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false,
                "red", "yellow");
        s.changeToExtractionMode();
        String hold = s.removeFirst();
        assertEquals(sExpected, s);
        assertEquals("blue", hold);
    }

    /**
     * test removeFirstEmpty when multiple elements of similar name. Challenging
     * test.
     */
    @Test
    public final void testremoveFirstMultipleSimilar() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true,
                "yyellow", "yyyellow", "yellow", "yyyyellow");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false,
                "yyyellow", "yyellow", "yyyyellow");
        s.changeToExtractionMode();
        String hold = s.removeFirst();
        assertEquals(sExpected, s);
        assertEquals("yellow", hold);
    }

    /**
     * Test for when isInInsertionMode is true when Empty. Routine test.
     */
    @Test
    public final void testisInInsertionModeTrueEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true);
        boolean result = s.isInInsertionMode();
        assertEquals(sExpected, s);
        assertEquals(true, result);
    }

    /**
     * Test for when isInInsertionMode is true when full. Challenging test.
     */
    @Test
    public final void testisInInsertionModeTrueFull() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "zero",
                "one", "two", "three");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "zero", "one", "two", "three");
        boolean result = s.isInInsertionMode();
        assertEquals(sExpected, s);
        assertEquals(true, result);
    }

    /**
     * Test for when isInInsertionMode is false when Empty. Routine test.
     */
    @Test
    public final void testisInInsertionModeFalseEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false);
        boolean result = s.isInInsertionMode();
        assertEquals(sExpected, s);
        assertEquals(false, result);
    }

    /**
     * Test for when isInInsertionMode is false when full. Challenging test.
     */
    @Test
    public final void testisInInsertionModeFalseFull() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, false, "zero",
                "one", "two", "three");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false,
                "zero", "one", "two", "three");
        boolean result = s.isInInsertionMode();
        assertEquals(sExpected, s);
        assertEquals(false, result);
    }

    /**
     * Test Order when empty. Routine test.
     */
    @Test
    public final void testOrderEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true);
        s.order();
        assertEquals(sExpected, s);
    }

    /**
     * Test Order when empty and falase. Routine test.
     */
    @Test
    public final void testOrderEmptyFalse() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false);
        s.order();
        assertEquals(sExpected, s);
    }

    /**
     * Test Order with One element. Routine test.
     */
    @Test
    public final void testOrderOneElement() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "a");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "a");
        s.order();
        assertEquals(sExpected, s);
    }

    /**
     * Test Order when few elements. Routine test.
     */
    @Test
    public final void testOrderFewElements() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "d",
                "c", "a", "b");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c", "d");
        s.order();
        assertEquals(sExpected, s);
    }

    /**
     * Test Order when many elements. Challenging test.
     */
    @Test
    public final void testOrderManyElements() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "i",
                "c", "k", "b", "f", "j", "g", "d", "h", "e", "a");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k");
        s.order();
        assertEquals(sExpected, s);
    }

    /**
     * Test Order when many elements and false. Challenging test.
     */
    @Test
    public final void testOrderManyElementsFalse() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, false, "i",
                "c", "k", "b", "f", "j", "g", "d", "h", "e", "a");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false,
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k");
        s.order();
        assertEquals(sExpected, s);
    }

    /**
     * Test Size when empty. Routine test.
     */
    @Test
    public final void testSizeEmpty() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true);
        int result = s.size();
        assertEquals(sExpected, s);
        assertEquals(0, result);
    }

    /**
     * Test Size when empty and false. Routine test.
     */
    @Test
    public final void testSizeEmptyFalse() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false);
        int result = s.size();
        assertEquals(sExpected, s);
        assertEquals(0, result);
    }

    /**
     * Test Size when empty. Routine test.
     */
    @Test
    public final void testSizeFewElements() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "zero",
                "one", "two", "three");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "zero", "one", "two", "three");
        int result = s.size();
        assertEquals(sExpected, s);
        assertEquals(4, result);
    }

    /**
     * Test Size when containing multiple elements. Challenging test.
     */
    @Test
    public final void testSizeMultiple() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, true, "0",
                "1", "2", "3", "4", "5", "6", "7", "8", "9");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, true,
                "0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
        int result = s.size();
        assertEquals(sExpected, s);
        assertEquals(10, result);
    }

    /**
     * Test Size when containing multiple elements and false. Challenging test.
     */
    @Test
    public final void testSizeMultipleFalse() {
        SortingMachine<String> s = this.createFromArgsTest(ORDER, false, "0",
                "1", "2", "3", "4", "5", "6", "7", "8", "9");
        SortingMachine<String> sExpected = this.createFromArgsRef(ORDER, false,
                "0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
        int result = s.size();
        assertEquals(sExpected, s);
        assertEquals(10, result);
    }

}
