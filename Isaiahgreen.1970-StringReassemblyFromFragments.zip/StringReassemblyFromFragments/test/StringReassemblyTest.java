import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    @Test
    public void overlap1() {
        int factor = StringReassembly.overlap("hlleo", "hello");
        assertEquals(factor, 0);
    }

    /*
     * The test is a boundary
     */
    @Test
    public void overlap2() {
        int factor = StringReassembly.overlap("kenobi", "canoli");
        assertEquals(factor, 0);
    }

    /*
     * The test is a routine
     */
    @Test
    public void overlap3() {
        int factor = StringReassembly.overlap("magnificent",
                "supercalifragilisticexpialidocious");
        assertEquals(factor, 0);
    }

    /*
     * The test is a challenging
     */
    @Test
    public void combination() {
        String yehaw = "CGAGGTAGT";
        String sixtynine = "AGTAGAACG";
        int overlap = StringReassembly.overlap(yehaw, sixtynine);
        String combined = StringReassembly.combination(yehaw, sixtynine,
                overlap);
        assertEquals("CGAGGTAGTAGAACG", combined);
    }

    @Test
    public void combination1() {
        String combo = StringReassembly.combination("hello", "world", 0);
        assertEquals(combo, "helloworld");

    }
    /*
     * The test is a boundary
     */

    @Test
    public void combination2() {
        String combo = StringReassembly.combination("parakeet", "bear", 0);
        assertEquals(combo, "parakeetbear");
    }
    /*
     * The test is a routine
     */

    @Test
    public void combination3() {
        String combo = StringReassembly.combination("yeehhaaw", "sixtynine", 0);
        assertEquals(combo, "yeehhaawsixtynine");
    }

    /*
     * The test is a challenging
     */

    @Test
    public void addToSetAvoidingSubstrings1() {

        String x = "how are you";
        Set<String> y = new Set1L<>();
        y.add("how are you doing");
        Set<String> expected = new Set1L<>();
        expected.add("how are you doing");
        StringReassembly.addToSetAvoidingSubstrings(y, x);
        assertEquals(expected, y);

    }

    /*
     * The test is a boundary
     */
    @Test
    public void addToSetAvoidingSubstrings2() {

        String x = "is this a great day to do work";
        Set<String> y = new Set1L<>();
        y.add("is this a great day to do works");
        Set<String> expected = new Set1L<>();
        expected.add("is this a great day to do works");
        StringReassembly.addToSetAvoidingSubstrings(y, x);
        assertEquals(expected, y);
    }

    /*
     * The test is a routine
     */
    @Test
    public void addToSetAvoidingSubstrings3() {

        String x = "are supercalifragilisticexpialidocious yeehaw yes";
        Set<String> y = new Set1L<>();
        y.add("are supercalifragilisticexpialidocious yeehaw yes it");
        Set<String> expected = new Set1L<>();
        expected.add("are supercalifragilisticexpialidocious yeehaw yes it");
        StringReassembly.addToSetAvoidingSubstrings(y, x);
        assertEquals(expected, y);
    }

    /*
     * The test is a challenging
     */
    @Test
    public void linesFromInput1() {

        Set<String> boo = new Set1L<>();
        Set<String> expected = boo.newInstance();
        SimpleReader x = new SimpleReader1L("data/sixtynine.txt");
        expected.add("yeehaw");
        expected.add("sixtynine");
        expected.add("poop");
        expected.add("hello");
        Set<String> G = StringReassembly.linesFromInput(x);
        assertEquals(expected, G);
    }

    /*
     * The test is a boundary
     */
    @Test
    public void linesFromInput2() {

        Set<String> boo = new Set1L<>();
        Set<String> expected = boo.newInstance();
        SimpleReader x = new SimpleReader1L("data/bobo.txt");
        expected.add("yeehaw");
        expected.add("poop");
        Set<String> G = StringReassembly.linesFromInput(x);
        assertEquals(expected, G);
    }

    /*
     * The test is a routine
     */
    @Test
    public void linesFromInput3() {

        Set<String> boo = new Set1L<>();
        Set<String> expected = boo.newInstance();
        SimpleReader x = new SimpleReader1L("data/yeehhaaw.txt");
        expected.add("how");
        expected.add("do");
        expected.add("you");
        expected.add("make");
        expected.add("happy");
        expected.add("day");
        Set<String> G = StringReassembly.linesFromInput(x);
        assertEquals(expected, G);
    }

    /*
     * The test is a challenging
     */
    @Test
    public void printWithLineSeparators1() {

        SimpleWriter x = new SimpleWriter1L("A.txt");
        String test = "ab~d";
        Set<String> expected = new Set1L<>();
        Set<String> actual = new Set1L<>();
        StringReassembly.printWithLineSeparators(test, x);
        SimpleReader boo = new SimpleReader1L("A.txt");
        expected.add("ab");
        expected.add("d");
        while (!boo.atEOS()) {
            actual.add(boo.nextLine());
        }
        assertEquals(actual, expected);
    }

    /*
     * The test is a boundary
     */
    @Test
    public void printWithLineSeparators2() {

        SimpleWriter x = new SimpleWriter1L("A.txt");
        String test = "a~b~d~e~f~g~h~lost";
        Set<String> expected = new Set1L<>();
        Set<String> actual = new Set1L<>();
        StringReassembly.printWithLineSeparators(test, x);
        SimpleReader boo = new SimpleReader1L("A.txt");
        expected.add("a");
        expected.add("b");
        expected.add("d");
        expected.add("e");
        expected.add("f");
        expected.add("g");
        expected.add("h");
        expected.add("lost");
        while (!boo.atEOS()) {
            actual.add(boo.nextLine());
        }
        assertEquals(actual, expected);
    }

    /*
     * The test is a routine
     */
    @Test
    public void printWithLineSeparators3() {

        SimpleWriter x = new SimpleWriter1L("A.txt");
        String test = "supercalifragilisticexpialidocious~and~his~name~is~john~cena";
        Set<String> expected = new Set1L<>();
        Set<String> actual = new Set1L<>();
        StringReassembly.printWithLineSeparators(test, x);
        SimpleReader boo = new SimpleReader1L("A.txt");
        expected.add("supercalifragilisticexpialidocious");
        expected.add("and");
        expected.add("his");
        expected.add("name");
        expected.add("is");
        expected.add("john");
        expected.add("cena");
        while (!boo.atEOS()) {
            actual.add(boo.nextLine());
        }
        assertEquals(actual, expected);
    }
    /*
     * The test is a challenging
     */
}
